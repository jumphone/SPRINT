# coding: utf-8
import re
from tools_fq import *
from tools_sam import *
from tools_bed import *
from tools_zf import *
from tools_fa import *
import sprint_main
import sprint_prepare
from pipeline import *
import tmp
#import __main__

#from __main__ import *

def main():
#   if __name__=="__main__":
       pipeline() 
    









